from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from app import db
from app.models import Usuario, Pilar

admin_bp = Blueprint('admin', __name__, url_prefix='/admin')

# Decorador de seguridad: solo Dirección puede acceder
@admin_bp.before_request
@login_required
def verificar_acceso_direccion():
    if not current_user.es_direccion:
        flash('Acceso restringido únicamente para el área de Dirección.', 'danger')
        return redirect(url_for('dashboard.index'))

# ==========================================================
# CRUD DE USUARIOS
# ==========================================================

@admin_bp.route('/usuarios')
def usuarios():
    lista_usuarios = Usuario.query.order_by(Usuario.nombre_completo.asc()).all()
    lista_pilares = Pilar.query.order_by(Pilar.nombre.asc()).all()
    return render_template('admin/usuarios.html', usuarios=lista_usuarios, pilares=lista_pilares)

@admin_bp.route('/usuarios/crear', methods=['POST'])
def crear_usuario():
    nombre = request.form.get('nombre_completo', '').strip()
    username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip() or None  # Si está vacío, se guarda como None (NULL)
    password = request.form.get('password', '').strip()
    rol = request.form.get('rol', 'COLABORADOR')
    pilar_id = request.form.get('pilar_id', type=int) or None
    es_responsable = request.form.get('es_responsable') == '1'

    # Validaciones
    if not nombre or not username or not password:
        flash('Nombre completo, usuario y contraseña son obligatorios.', 'warning')
        return redirect(url_for('admin.usuarios'))

    # Comprobar si el username ya existe
    if Usuario.query.filter_by(username=username).first():
        flash(f'El nombre de usuario @{username} ya está registrado.', 'danger')
        return redirect(url_for('admin.usuarios'))

    # Comprobar si el correo ya existe SOLO si se ingresó un correo
    if email and Usuario.query.filter_by(email=email).first():
        flash(f'El correo {email} ya pertenece a otro usuario.', 'danger')
        return redirect(url_for('admin.usuarios'))

    # Si se marca como responsable, su rol pasa a ser LIDER_PILAR
    if es_responsable and rol != 'DIRECCION':
        rol = 'LIDER_PILAR'

    nuevo = Usuario(
        nombre_completo=nombre,
        username=username,
        email=email,
        rol=rol,
        pilar_id=pilar_id,
        es_responsable=es_responsable,
        activo=True
    )
    nuevo.set_password(password)
    db.session.add(nuevo)
    db.session.commit()

    # Si es responsable, asociar al pilar
    if es_responsable and pilar_id:
        pilar = Pilar.query.get(pilar_id)
        if pilar:
            Usuario.query.filter(Usuario.pilar_id == pilar_id, Usuario.id != nuevo.id).update({'es_responsable': False})
            pilar.responsable_id = nuevo.id
            db.session.commit()

    flash(f'Usuario {nuevo.nombre_completo} registrado exitosamente.', 'success')
    return redirect(url_for('admin.usuarios'))

@admin_bp.route('/usuarios/<int:usuario_id>/editar', methods=['POST'])
def editar_usuario(usuario_id):
    u = Usuario.query.get_or_404(usuario_id)
    u.nombre_completo = request.form.get('nombre_completo', '').strip()
    u.username = request.form.get('username', '').strip()
    email = request.form.get('email', '').strip() or None
    u.rol = request.form.get('rol', u.rol)
    u.activo = request.form.get('activo') == '1'
    
    pilar_id = request.form.get('pilar_id', type=int) or None
    es_responsable = request.form.get('es_responsable') == '1'

    # Validar que el username no esté en uso por otro usuario
    if Usuario.query.filter(Usuario.username == u.username, Usuario.id != u.id).first():
        flash(f'El usuario @{u.username} ya está en uso.', 'danger')
        return redirect(url_for('admin.usuarios'))

    # Validar correo duplicado SOLO si se ingresó uno
    if email:
        duplicado = Usuario.query.filter(Usuario.email == email, Usuario.id != u.id).first()
        if duplicado:
            flash(f'El correo {email} ya está registrado con otro usuario.', 'danger')
            return redirect(url_for('admin.usuarios'))

    u.email = email
    u.pilar_id = pilar_id
    u.es_responsable = es_responsable

    if es_responsable and u.rol != 'DIRECCION':
        u.rol = 'LIDER_PILAR'

    if es_responsable and pilar_id:
        pilar = Pilar.query.get(pilar_id)
        if pilar:
            Usuario.query.filter(Usuario.pilar_id == pilar_id, Usuario.id != u.id).update({'es_responsable': False})
            pilar.responsable_id = u.id
    elif not es_responsable and pilar_id:
        pilar = Pilar.query.get(pilar_id)
        if pilar and pilar.responsable_id == u.id:
            pilar.responsable_id = None

    db.session.commit()
    flash(f'Datos del usuario {u.nombre_completo} actualizados.', 'success')
    return redirect(url_for('admin.usuarios'))

@admin_bp.route('/usuarios/<int:usuario_id>/password', methods=['POST'])
def cambiar_password(usuario_id):
    u = Usuario.query.get_or_404(usuario_id)
    nueva_pass = request.form.get('password', '').strip()
    if not nueva_pass:
        flash('La contraseña no puede estar vacía.', 'warning')
    else:
        u.set_password(nueva_pass)
        db.session.commit()
        flash(f'Contraseña restablecida exitosamente para {u.username}.', 'success')
    return redirect(url_for('admin.usuarios'))

# ==========================================================
# CRUD DE PILARES
# ==========================================================

@admin_bp.route('/pilares')
def pilares():
    lista_pilares = Pilar.query.order_by(Pilar.nombre.asc()).all()
    lista_usuarios = Usuario.query.filter_by(activo=True).order_by(Usuario.nombre_completo.asc()).all()
    return render_template('admin/pilares.html', pilares=lista_pilares, usuarios=lista_usuarios)

@admin_bp.route('/pilares/crear', methods=['POST'])
def crear_pilar():
    nombre = request.form.get('nombre', '').strip()
    descripcion = request.form.get('descripcion', '').strip()
    color = request.form.get('color_identificador', '#2563eb')
    responsable_id = request.form.get('responsable_id', type=int) or None

    if not nombre:
        flash('El nombre del pilar es obligatorio.', 'warning')
        return redirect(url_for('admin.pilares'))

    if Pilar.query.filter_by(nombre=nombre).first():
        flash('Ya existe un pilar con ese nombre.', 'danger')
        return redirect(url_for('admin.pilares'))

    nuevo = Pilar(
        nombre=nombre,
        descripcion=descripcion,
        color_identificador=color,
        responsable_id=responsable_id
    )
    db.session.add(nuevo)
    db.session.commit()

    if responsable_id:
        user = Usuario.query.get(responsable_id)
        if user:
            user.pilar_id = nuevo.id
            user.es_responsable = True
            db.session.commit()

    flash(f'Pilar {nuevo.nombre} registrado con éxito.', 'success')
    return redirect(url_for('admin.pilares'))

@admin_bp.route('/pilares/<int:pilar_id>/editar', methods=['POST'])
def editar_pilar(pilar_id):
    p = Pilar.query.get_or_404(pilar_id)
    p.nombre = request.form.get('nombre', '').strip()
    p.descripcion = request.form.get('descripcion', '').strip()
    p.color_identificador = request.form.get('color_identificador', p.color_identificador)
    
    nuevo_resp_id = request.form.get('responsable_id', type=int) or None

    # Si cambió de responsable
    if p.responsable_id != nuevo_resp_id:
        if p.responsable_id:
            antiguo = Usuario.query.get(p.responsable_id)
            if antiguo:
                antiguo.es_responsable = False
        
        p.responsable_id = nuevo_resp_id
        if nuevo_resp_id:
            nuevo_resp = Usuario.query.get(nuevo_resp_id)
            if nuevo_resp:
                nuevo_resp.pilar_id = p.id
                nuevo_resp.es_responsable = True

    db.session.commit()
    flash(f'Pilar {p.nombre} actualizado correctamente.', 'success')
    return redirect(url_for('admin.pilares'))

@admin_bp.route('/pilares/<int:pilar_id>/miembros', methods=['GET'])
def miembros_pilar(pilar_id):
    pilar = Pilar.query.get_or_404(pilar_id)
    return jsonify({
        'pilar': pilar.nombre,
        'color': pilar.color_identificador,
        'miembros': [m.to_dict() for m in pilar.miembros]
    })